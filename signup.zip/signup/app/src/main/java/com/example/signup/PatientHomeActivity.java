package com.example.signup;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class PatientHomeActivity extends AppCompatActivity {

    Button expandButton, logoutButton;
    CheckBox vibrateCheckbox, ringCheckbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_home);

        expandButton = findViewById(R.id.expandButton);
        logoutButton = findViewById(R.id.logoutButton);
        vibrateCheckbox = findViewById(R.id.vibrateCheckbox);
        ringCheckbox = findViewById(R.id.ringCheckbox);

        expandButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Expand medical records logic
                Toast.makeText(PatientHomeActivity.this, "Medical Records Expanded", Toast.LENGTH_SHORT).show();
            }
        });

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Log out logic
                Toast.makeText(PatientHomeActivity.this, "Logged Out", Toast.LENGTH_SHORT).show();

                // Start LoginActivity
                Intent intent = new Intent(PatientHomeActivity.this, LoginActivity.class);
                startActivity(intent);

                // Finish current activity
                finish();
            }
        });
    }
    }