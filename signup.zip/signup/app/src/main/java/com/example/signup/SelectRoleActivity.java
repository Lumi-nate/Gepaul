package com.example.signup;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;

public class SelectRoleActivity extends AppCompatActivity {

    Button doctorButton, patientButton, secretaryButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_role);

        doctorButton = findViewById(R.id.doctorButton);
        patientButton = findViewById(R.id.patientButton);
        secretaryButton = findViewById(R.id.secretaryButton);

        doctorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(SelectRoleActivity.this, "Doctor Selected", Toast.LENGTH_SHORT).show();
                // You can proceed to Doctor setup activity here
            }
        });

        patientButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(SelectRoleActivity.this, "Patient Selected", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent (SelectRoleActivity.this, PatientHomeActivity.class);
                startActivity(intent);
                finish();
                // You can proceed to Patient setup activity here
            }
        });

        secretaryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(SelectRoleActivity.this, "Secretary Selected", Toast.LENGTH_SHORT).show();
                // You can proceed to Secretary setup activity here
            }
        });
    }
}