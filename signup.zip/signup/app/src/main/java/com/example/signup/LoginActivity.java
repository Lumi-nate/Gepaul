package com.example.signup;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText usernamePhoneEditText, passwordEditText;
    Button logInButton;
    CheckBox rememberMeCheckbox;
    TextView signUpTextView, forgotPasswordTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // <-- Make sure your login XML is named activity_login.xml

        usernamePhoneEditText = findViewById(R.id.usernamePhoneEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        logInButton = findViewById(R.id.logInButton);
        rememberMeCheckbox = findViewById(R.id.rememberMeCheckbox);
        signUpTextView = findViewById(R.id.signUpTextView);
        forgotPasswordTextView = findViewById(R.id.forgotPasswordTextView);

        usernamePhoneEditText.addTextChangedListener(textWatcher);
        passwordEditText.addTextChangedListener(textWatcher);

        // Log In Button Action
        logInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInputs()) {
                    Toast.makeText(LoginActivity.this, "Logged in successfully!", Toast.LENGTH_SHORT).show();

                    // After login, move to SelectRoleActivity or your Home Activity
                    Intent intent = new Intent(LoginActivity.this, PatientHomeActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        });

        // Sign Up Text Click
        signUpTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(intent);
                finish();
            }
        });

        // Forgot Password Click
        forgotPasswordTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // You can show a Toast or redirect to ForgotPasswordActivity
                Toast.makeText(LoginActivity.this, "Forgot Password clicked!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private final TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            logInButton.setEnabled(areFieldsFilled());
        }

        @Override
        public void afterTextChanged(Editable s) {}
    };

    private boolean areFieldsFilled() {
        return !usernamePhoneEditText.getText().toString().isEmpty()
                && !passwordEditText.getText().toString().isEmpty();
    }

    private boolean validateInputs() {
        boolean valid = true;

        if (usernamePhoneEditText.getText().toString().trim().isEmpty()) {
            usernamePhoneEditText.setError("Username or Phone Number is required");
            valid = false;
        }

        if (passwordEditText.getText().toString().trim().isEmpty()) {
            passwordEditText.setError("Password is required");
            valid = false;
        }

        return valid;
    }
}
