package com.example.signup;

import android.content.Intent; // <-- ADD THIS import
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SignUpActivity extends AppCompatActivity {

    EditText fullNameEditText, phoneNumberEditText, passwordEditText, confirmPasswordEditText;
    Button signUpButton;
    TextView loginTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fullNameEditText = findViewById(R.id.fullNameEditText);
        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText);
        signUpButton = findViewById(R.id.signUpButton);
        loginTextView = findViewById(R.id.loginTextView);

        // Add text watchers
        fullNameEditText.addTextChangedListener(textWatcher);
        phoneNumberEditText.addTextChangedListener(textWatcher);
        passwordEditText.addTextChangedListener(textWatcher);
        confirmPasswordEditText.addTextChangedListener(textWatcher);

        // Sign Up Button Action
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInputs()) {
                    Toast.makeText(SignUpActivity.this, "Account created successfully!", Toast.LENGTH_SHORT).show();

                    // 🚀 After successful signup, move to SelectRoleActivity
                    Intent intent = new Intent(SignUpActivity.this, SelectRoleActivity.class);
                    startActivity(intent);
                    finish(); // Finish SignUpActivity so user can't go back
                }
            }
        });

        // Log In Text Click
        loginTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
                // Go to LoginActivity (not implemented yet)
            }
        });
    }

    // Watch for typing changes
    private final TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            // Not needed
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // Optional: Enable/disable the button
            signUpButton.setEnabled(areFieldsFilled());
        }

        @Override
        public void afterTextChanged(Editable s) {
            // Optional: live password match checking
            if (!passwordEditText.getText().toString().equals(confirmPasswordEditText.getText().toString())) {
                confirmPasswordEditText.setError("Passwords do not match");
            }
        }
    };

    private boolean areFieldsFilled() {
        return !fullNameEditText.getText().toString().isEmpty()
                && !phoneNumberEditText.getText().toString().isEmpty()
                && !passwordEditText.getText().toString().isEmpty()
                && !confirmPasswordEditText.getText().toString().isEmpty();
    }

    private boolean validateInputs() {
        boolean valid = true;

        if (fullNameEditText.getText().toString().trim().isEmpty()) {
            fullNameEditText.setError("Full Name is required");
            valid = false;
        }

        if (phoneNumberEditText.getText().toString().trim().isEmpty()) {
            phoneNumberEditText.setError("Phone Number is required");
            valid = false;
        }

        if (passwordEditText.getText().toString().trim().isEmpty()) {
            passwordEditText.setError("Password is required");
            valid = false;
        }

        if (confirmPasswordEditText.getText().toString().trim().isEmpty()) {
            confirmPasswordEditText.setError("Please confirm your password");
            valid = false;
        }

        if (!passwordEditText.getText().toString().equals(confirmPasswordEditText.getText().toString())) {
            confirmPasswordEditText.setError("Passwords do not match");
            valid = false;
        }

        return valid;
    }
}
